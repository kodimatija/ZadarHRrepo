import xbmcaddon

MainBase = ('WVVoU01HTklUVFpNZVRsellWaGFiR1JJV25KaU1sSndZekpXZVZsdGJHaE1iVTUyWWxN'.decode('base64')+'NWFGcEhVblppYm1oMFlrTTVjbGxYTldoaVIydDJZVEk1YTJGWVRubFpiV3h4V1ZNMWQyRklRVDA9'.decode('base64')).decode('base64').decode('base64')
LSProFile = 'https://livetvkodiserbia.com/addonxml/kanali/LSProdynamicCode.py'
addon = xbmcaddon.Addon('plugin.video.livetvSerbia')