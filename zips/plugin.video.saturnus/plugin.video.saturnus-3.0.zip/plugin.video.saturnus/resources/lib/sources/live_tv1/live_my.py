# -*- coding: utf-8 -*-
from resources.lib.modules import client,epg,convert,control
import re
from resources.lib.modules.log_utils import log
import sys,xbmcgui,os,base64


class info():
    def __init__(self):
    	self.mode = 'live_my'
        self.name = 'Live TV & EPG'
        self.icon = 'TV1.gif'
        self.paginated = False
        self.categorized = True
        self.multilink = False
        
class main():
	def __init__(self,url = base64.b64decode('https://kodimasterzd.webshopp.net/live/')):
		self.base = base64.b64decode('https://kodimasterzd.webshopp.net/live/')
		self.url = url

	def categories(self):
		cats=[['Hrvatski','hrvatski','http://kodimasterzd.webshopp.net/TVpng/Flag_of_Croatia.png'],
		['Dokumentarci','Dokumentarci-eng','http://kodimasterzd.webshopp.net/TVpng/dokumentarci.png'],
		['Sport','sport','http://kodimasterzd.webshopp.net/TVpng/sport.png'],
		['Filmovi/serije','film-serije','http://kodimasterzd.webshopp.net/TVpng/PNGPIX-COM-Film-Camera-PNG-Transparent-Image-500x557.png'],
		['Lifestyle','lifestyle','http://kodimasterzd.webshopp.net/TVpng/beach-deck-chairs-maldives.png'],
		['Glazba','tv-music','http://kodimasterzd.webshopp.net/TVpng/Music-Girls-Latest-Images.png'],
		['Dječji programi','djecji','http://kodimasterzd.webshopp.net/TVpng/DisneyWorld_MickeyGang_Castle.png'],
		['PINK','pink','http://kodimasterzd.webshopp.net/TVpng/4e401a24c35a57ead8327054c3ca6d98_400x400.png'],
		['Regionalni','regionalni','http://kodimasterzd.webshopp.net/TVpng/zastave3d.png'],
		['Video/Crtani/Film','video','http://kodimasterzd.webshopp.net/TVpng/video.png'],
		['XXX','xxx','http://kodimasterzd.webshopp.net/TVpng/rosiebed.png'],
		['Saturnus Premium naruci!!!','iptv','http://kodimasterzd.webshopp.net/TVpng/IPTV.png'],
		['Donacija','news','http://kodimasterzd.webshopp.net/TVpng/Paypal-logo-201710190752.png']]
		out = []
		for cat in cats:
			title = cat[0]
			url = self.base +  cat[1] + '.txt'
			img = cat[2]
			out.append((url,title,img))
		return out

	def channels(self,url):
		html = client.request(url)
		urls = re.findall('url\s*=\s*"(.+?)"',html)
		imgs = re.findall('img\s*=\s*"(.+?)"',html)
		titles = re.findall('ime\s*=\s*"(.+?)"',html,flags=re.UNICODE)
		epgs = re.findall('epg\s*=\s*"(.+?)"',html)
		events = self.__prepare_channels(urls,titles,imgs,epgs)
		return events

	def __prepare_channels(self,urls,titles,imgs,epgs):
		new=[]
		for i in range(len(urls)):
			url = urls[i]
			img = imgs[i]
			title = titles[i].decode('utf-8')
			epgx = self.get_epg(epgs[i])
			title = '[B]%s[/B] - [I][COLOR red]%s[/COLOR][/I]'%(title,epgx)
			title = convert.unescape(title)
			new.append((url,title.encode('utf-8'),img))
		return new

	def get_epg(self,epgx):
		return epg.get_current_epg(epgx)

	def resolve(self,url):
		urls = url.split('##')
		choices = ['Stream %s'%(i+1) for i in range(len(urls))]
		
		if len(choices)==1:
			index=0
		else:
			index = control.selectDialog(choices,'Odaberite Stream:')
		if index>-1:
			url = urls[index]
			if 'morescreens' in url:
				from resources.lib.resolvers import hrti
				return hrti.resolve(url)

			elif 'streamlive.to' in url:
				from resources.lib.resolvers import streamlive
				return streamlive.resolve(url)

			elif 'dailymotion' in url:
				import urlresolver
				return urlresolver.resolve(url)


			#nova tv, doma tv
			specy = {'http://www.sipragezabava.com/kanal_3_hr.php':'http://prvenstvoliga.blogspot.hr/2014/12/nova-tv.html',
					'http://www.netraja.net/2014/05/doma-tv.html':'http://www.prvenstvoliga.blogspot.hr/2014/05/doma-tv.html'}
			if url in specy.keys():
				urlx = []
				src = []
				html = client.request(specy[url],referer='http://prvenstvoliga.blogspot.com/search/label/Hrvatska')
				urls = re.findall('target=[\"\']([^\"\']+)[\"\'].+?</embed>',html)
				i=0
				for url in urls:
					i+=1
					src+=['Stream %s'%i]
					
				dialog = xbmcgui.Dialog()
				index = dialog.select('Odaberite:', src)
				if index==-1:
					return ''
				return urlx[index]

			import liveresolver
			return liveresolver.resolve(url)
	


		return ''