from __future__ import unicode_literals
from resources.lib.modules import client,webutils,convert,control
from resources.lib.modules.log_utils import log
import xbmc
xbmc.executebuiltin("RunAddon(plugin.video.saturnusworld)")


AddonPath = control.addonPath
IconPath = AddonPath + "/resources/media/"
def icon_path(filename):
    return os.path.join(IconPath, filename)

class info():
    def __init__(self):
    	self.mode = 'saturnusworld'
        self.name = 'Saturnus World'
        self.icon = icon_path('world.png')
        self.paginated = True
        self.categorized = True
        self.multilink = False
        self.paginated_links = False


